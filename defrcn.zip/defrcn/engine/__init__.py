from .defaults import Trainer, TwoSteamTrainer, DefaultPredictor, DefaultTrainer, default_argument_parser, default_setup
from .hooks import *
from .defaults_1 import default_argument_parser_coco, default_setup_coco
