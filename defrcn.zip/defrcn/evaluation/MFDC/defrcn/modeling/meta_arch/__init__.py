from .build import META_ARCH_REGISTRY, build_model
from .rcnn import GeneralizedRCNN
